<?php

require_once "models/shop.php";
include("header.php");

$city  = shopDB::getCity(array(1,2));

echo "<pre>";
var_dump($city);
echo "</pre>";

?>