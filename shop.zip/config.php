<?php
define('DB_PERSISTENCY', 'true');
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'shop');
define('DB_PASSWORD', 'shop');
define('DB_DATABASE', 'shop');
define('PDO_DSN', 'mysql:host=' . DB_SERVER . ';dbname=' . DB_DATABASE);
?>
